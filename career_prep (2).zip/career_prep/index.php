<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome - CareerPrep</title>
    <link rel="stylesheet" href="style.css?v=2">
</head>
<body>
    <div class="hero">
        <h1 style="color: rgba(255,255,255,0.3);">FAILURE</h1>
        <h1 style="color: white; text-shadow: 0 0 20px rgba(255,255,255,0.5);">SUCCESS</h1>
        
        <h2>Your Journey to a Dream Career Starts Here</h2>
        <p>Master skills, pass exams, and get hired by top companies.</p>
        
        <div class="btn-group">
            <a href="register.php" class="btn-landing btn-start">Get Started</a>
            <a href="login.php" class="btn-landing btn-login">Login</a>
        </div>
    </div>
</body>
</html>