<div class="sidebar">
    <h2>CareerPrep</h2>
    <a href="dashboard.php">📊 Dashboard</a>
    <a href="courses.php">🎬 Courses</a>
    <a href="exams.php">📝 Exams</a>
    <a href="jobs.php">💼 Jobs</a>
    <a href="resume.php">📄 Resume</a>

    <a href="profile.php">👤 My Profile</a>
    
    <hr>
    <a href="logout.php" style="color: #ef4444;">→ Logout</a>
</div>