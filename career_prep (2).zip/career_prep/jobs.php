<?php
session_start();
include 'db_connect.php';
$uid = $_SESSION['user_id'];
$cgpa = $_SESSION['cgpa'];

// জব এবং এক্সাম স্ট্যাটাস ফেচ করা
$sql = "SELECT j.*, s.name as sector_name, s.id as sec_id, r.status as exam_status
        FROM jobs j
        JOIN sectors s ON j.sector_id = s.id
        JOIN exams e ON e.sector_id = s.id
        LEFT JOIN user_exam_results r ON r.exam_id = e.id AND r.user_id = $uid
        ORDER BY j.id DESC"; // নতুন জব আগে দেখাবে
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html>
<head><link rel="stylesheet" href="style.css?v=8"></head>
<body>
    <div class="app-container">
        <?php include 'sidebar.php'; ?>
        <div class="main-content">
            <h1 style="margin-bottom:10px;">Explore Jobs</h1>
            <p style="color:#666; margin-bottom:30px;">Find a job you like. If locked, take the skill assessment to unlock.</p>

            <div class="card-grid">
                <?php while($row = $result->fetch_assoc()): 
                    $passed = ($row['exam_status'] == 'PASS');
                    $cgpa_ok = ($cgpa >= $row['min_cgpa']);
                    $unlocked = ($passed && $cgpa_ok);
                ?>
                <div class="card" style="position:relative;">
                    <span class="tag"><?php echo $row['sector_name']; ?></span>
                    
                    <h3 style="margin:10px 0 5px 0;"><?php echo $row['title']; ?></h3>
                    <p style="color:#64748b; font-size:14px; margin:0;"><?php echo $row['company']; ?></p>
                    <p style="color:#059669; font-weight:bold; font-size:14px; margin-top:5px;"><?php echo $row['salary_range']; ?></p>
                    
                    <div style="background:#f8fafc; padding:12px; border-radius:8px; font-size:13px; margin:15px 0; border:1px solid #e2e8f0;">
                        <div style="display:flex; justify-content:space-between; margin-bottom:5px;">
                            <span>CGPA Req: <strong><?php echo $row['min_cgpa']; ?></strong></span>
                            <?php echo $cgpa_ok ? "✅" : "❌"; ?>
                        </div>
                        <div style="display:flex; justify-content:space-between;">
                            <span>Skill Exam:</span>
                            <?php 
                                if($passed) echo "<span style='color:green; font-weight:bold;'>Passed</span>";
                                elseif($row['exam_status'] == 'FAIL') echo "<span style='color:red; font-weight:bold;'>Failed</span>";
                                else echo "<span style='color:orange; font-weight:bold;'>Not Taken</span>";
                            ?>
                        </div>
                    </div>

                    <?php if($unlocked): ?>
                        <button class="btn-primary" onclick="alert('Application Sent Successfully!')" style="background:#10b981;">Apply Now</button>
                    <?php else: ?>
                        <button class="btn-locked" style="margin-bottom:10px;">Locked 🔒</button>
                        
                        <?php if(!$passed): ?>
                            <a href="exams.php?sector=<?php echo $row['sec_id']; ?>" 
                               class="btn-primary" 
                               style="display:block; text-align:center; text-decoration:none; background:#2563eb;">
                               Take <?php echo $row['sector_name']; ?> Exam
                            </a>
                        <?php else: ?>
                            <small style="color:red; display:block; text-align:center;">Low CGPA</small>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
                <?php endwhile; ?>
            </div>
        </div>
    </div>
</body>
</html>