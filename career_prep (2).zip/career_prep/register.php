<?php
include 'db_connect.php';
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['full_name'];
    $email = $_POST['email'];
    $pass = $_POST['password']; 
    // CGPA এখন ডিফল্টভাবে 0.00 থাকবে, পরে প্রোফাইলে আপডেট করবে
    $cgpa = 0.00; 

    $sql = "INSERT INTO users (full_name, email, password, cgpa) VALUES ('$name', '$email', '$pass', '$cgpa')";
    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('Account Created! Please Login.'); window.location.href='login.php';</script>";
    } else {
        echo "Error: " . $conn->error;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Account</title>
    <link rel="stylesheet" href="style.css?v=3">
    <style>
        body { margin: 0; font-family: 'Poppins', sans-serif; }
        .hero-bg {
            background: linear-gradient(rgba(0,0,0,0.6), rgba(0,0,0,0.7)), url('https://images.unsplash.com/photo-1497215728101-856f4ea42174');
            background-size: cover; height: 100vh; display: flex; justify-content: center; align-items: center;
        }
        .register-card { background: rgba(255,255,255,0.95); padding: 40px; width: 350px; border-radius: 15px; text-align: center; }
        input { width: 100%; padding: 12px; margin: 8px 0; border: 1px solid #ddd; border-radius: 6px; box-sizing: border-box; }
        button { width: 100%; padding: 12px; background: #10b981; color: white; border: none; border-radius: 6px; font-weight: bold; cursor: pointer; margin-top: 15px; }
    </style>
</head>
<body>
    <div class="hero-bg">
        <div class="register-card">
            <h2>Create Account</h2>
            <form method="post">
                <input type="text" name="full_name" placeholder="Full Name" required>
                <input type="email" name="email" placeholder="Email Address" required>
                <input type="password" name="password" placeholder="Password" required>
                <button type="submit">Sign Up</button>
            </form>
            <p style="margin-top:20px; font-size:14px;">Already have an account? <a href="login.php">Login</a></p>
        </div>
    </div>
</body>
</html>