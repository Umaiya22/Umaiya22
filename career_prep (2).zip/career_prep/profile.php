<?php
session_start();
include 'db_connect.php';
if (!isset($_SESSION['user_id'])) header("Location: index.php");

$uid = $_SESSION['user_id'];

// আপডেট লজিক
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $phone = $_POST['phone'];
    $location = $_POST['location'];
    
    $conn->query("UPDATE users SET phone='$phone', location='$location' WHERE id=$uid");
    echo "<script>alert('Profile Updated Successfully!');</script>";
}

// ডাটা আনা
$user = $conn->query("SELECT * FROM users WHERE id=$uid")->fetch_assoc();
$resume = $conn->query("SELECT * FROM resumes WHERE user_id=$uid")->fetch_assoc();
?>

<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="style.css?v=7">
</head>
<body>
    <div class="app-container">
        <?php include 'sidebar.php'; ?>
        
        <div class="main-content">
            <h1 style="margin-bottom: 30px; font-weight: 700; color: #111827;">My Profile</h1>
            
            <div class="profile-container">
                
                <div class="profile-card">
                    <h3 style="margin-top:0; margin-bottom: 25px; color: #2563eb; border-bottom: 1px solid #eee; padding-bottom: 15px;">
                        Personal Information
                    </h3>
                    
                    <form method="post">
                        <div class="form-group-row">
                            <div class="form-group">
                                <label>Full Name</label>
                                <input type="text" value="<?php echo $user['full_name']; ?>" class="form-control read-only" disabled>
                            </div>
                            <div class="form-group">
                                <label>Email Address</label>
                                <input type="email" value="<?php echo $user['email']; ?>" class="form-control read-only" disabled>
                            </div>
                        </div>

                        <div class="cgpa-box">
                            <div>
                                <label style="display:block; color:#047857; font-weight:bold; margin-bottom:5px;">Current CGPA</label>
                                <span style="font-size:13px; color:#059669;">Synced from Resume</span>
                            </div>
                            <div class="cgpa-value">
                                <?php echo $user['cgpa']; ?>
                            </div>
                        </div>

                        <div class="form-group-row">
                            <div class="form-group">
                                <label>Phone Number</label>
                                <input type="text" name="phone" value="<?php echo $user['phone'] ?? ''; ?>" class="form-control" placeholder="+880 1XXX...">
                            </div>
                            <div class="form-group">
                                <label>Location</label>
                                <input type="text" name="location" value="<?php echo $user['location'] ?? ''; ?>" class="form-control" placeholder="City, Country">
                            </div>
                        </div>

                        <div style="text-align: right;">
                            <button type="submit" class="btn-primary" style="width: auto; padding: 12px 30px;">Save Changes</button>
                        </div>
                    </form>
                </div>

                <div class="profile-card" style="background: #f8fafc; border: 1px solid #e2e8f0;">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                        <h3 style="margin:0; color: #475569;">Resume Snapshot</h3>
                        <a href="resume.php" style="font-size: 13px; color: #2563eb; text-decoration: none; font-weight: 600;">Edit ✎</a>
                    </div>
                    
                    <div style="margin-bottom: 25px;">
                        <h4 style="margin: 0 0 10px 0; font-size: 14px; text-transform: uppercase; color: #94a3b8;">Summary</h4>
                        <p style="color: #333; line-height: 1.6; font-size: 14px; background: white; padding: 15px; border-radius: 8px; border: 1px solid #e5e7eb;">
                            <?php echo !empty($resume['summary']) ? $resume['summary'] : '<span style="color:#999; font-style:italic;">No summary added yet.</span>'; ?>
                        </p>
                    </div>
                    
                    <div>
                        <h4 style="margin: 0 0 10px 0; font-size: 14px; text-transform: uppercase; color: #94a3b8;">Skills</h4>
                        <div style="background: white; padding: 15px; border-radius: 8px; border: 1px solid #e5e7eb; min-height: 50px;">
                            <?php 
                            if(!empty($resume['skills'])) {
                                $skills_arr = explode(',', $resume['skills']);
                                foreach($skills_arr as $s) {
                                    echo "<span class='skill-tag'>" . trim($s) . "</span>";
                                }
                            } else {
                                echo "<span style='color:#999; font-size:13px;'>No skills added.</span>";
                            }
                            ?>
                        </div>
                    </div>
                    
                    <button onclick="window.location.href='resume.php'" class="btn-primary" style="margin-top: 30px; background: #475569;">Update Full Resume</button>
                </div>

            </div>
        </div>
    </div>
</body>
</html>