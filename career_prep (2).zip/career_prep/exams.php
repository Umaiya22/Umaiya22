<?php
session_start();
include 'db_connect.php';
if (!isset($_SESSION['user_id'])) header("Location: index.php");

$user_id = $_SESSION['user_id'];
$sector_id = isset($_GET['sector']) ? $_GET['sector'] : 1;
$mode = isset($_GET['mode']) ? $_GET['mode'] : 'info'; // 'info' বা 'real'

// 1. Fetch Exam Info
$exam = $conn->query("SELECT * FROM exams WHERE sector_id = $sector_id")->fetch_assoc();
if(!$exam) { echo "Exam not found!"; exit; }
$exam_id = $exam['id'];

// 2. Check Result
$previous_result = $conn->query("SELECT * FROM user_exam_results WHERE user_id=$user_id AND exam_id=$exam_id")->fetch_assoc();

// 3. Handle Result Reset (Retake)
if(isset($_GET['reset'])) {
    $conn->query("DELETE FROM user_exam_results WHERE user_id=$user_id AND exam_id=$exam_id");
    header("Location: exams.php?sector=$sector_id");
    exit();
}

// 4. Handle Exam Submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $score_points = 0;
    $total_q = 5; 
    
    foreach($_POST as $key => $val) {
        if(strpos($key, 'q') === 0 && $val != 'SKIP') {
            $qid = $_POST['id_' . $key];
            $correct = $conn->query("SELECT correct_opt FROM questions WHERE id=$qid")->fetch_assoc()['correct_opt'];
            if($val == $correct) $score_points++;
        }
    }

    $final_score = ($score_points / $total_q) * 100;
    $status = ($final_score >= 70) ? 'PASS' : 'FAIL';
    
    $conn->query("INSERT INTO user_exam_results (user_id, exam_id, score, status) VALUES ($user_id, $exam_id, $final_score, '$status') 
                  ON DUPLICATE KEY UPDATE score=$final_score, status='$status'");
    header("Location: exams.php?sector=$sector_id");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head><link rel="stylesheet" href="style.css?v=10"></head>
<body>
    <div class="app-container">
        <?php include 'sidebar.php'; ?>
        
        <div class="main-content">
            <h1 style="margin-bottom:10px;">MCQ Exams</h1>
            
            <div style="margin-bottom: 30px; overflow-x:auto; white-space:nowrap; padding-bottom:10px;">
                <?php 
                $sectors = $conn->query("SELECT * FROM sectors");
                while($s = $sectors->fetch_assoc()) {
                    $active = ($s['id'] == $sector_id) ? "background:#111827; color:white;" : "background:white; color:#333; border:1px solid #ddd;";
                    echo "<a href='exams.php?sector=".$s['id']."' style='display:inline-block; padding:10px 20px; border-radius:30px; text-decoration:none; margin-right:10px; font-weight:600; font-size:14px; $active'>".$s['name']."</a>";
                }
                ?>
            </div>

            <?php if (isset($previous_result)): ?>
                
                <?php if ($previous_result['status'] == 'PASS'): ?>
                    <div class="exam-card-pro" style="border-left: 5px solid #10b981; text-align:center;">
                        <h1 style="color:#10b981; font-size:50px;">✔ Passed</h1>
                        <p>You scored <strong><?php echo $previous_result['score']; ?>%</strong></p>
                        <a href="jobs.php" class="btn-real" style="background:#10b981; display:inline-block; width:auto; padding:10px 30px;">Go to Jobs</a>
                    </div>
                <?php else: ?>
                    <div class="locked-container">
                        <div style="font-size: 60px; margin-bottom: 10px;">🔒</div>
                        <h1 style="color: #1f2937; margin: 0;">Access Locked</h1>
                        
                        <p style="color: #ef4444; font-weight: bold; font-size: 18px; margin-top: 5px;">
                            Score: <?php echo $previous_result['score']; ?>% (Failed)
                        </p>
                        
                        <div style="background: #fff7ed; border: 1px solid #ffedd5; padding: 15px; border-radius: 8px; margin: 20px auto; max-width: 600px;">
                            <p style="color: #9a3412; margin: 0 0 10px 0; font-weight: 600;">
                                🎓 Recommended: Watch this course to unlock retake
                            </p>
                            
                            <?php 
                            // শুধু ১টি কোর্স ফেচ করা হবে আনলক করার জন্য
                            $course = $conn->query("SELECT * FROM courses WHERE sector_id=$sector_id LIMIT 1")->fetch_assoc();
                            
                            if($course): ?>
                                <div style="position: relative; padding-bottom: 56.25%; height: 0; overflow: hidden; border-radius: 8px; box-shadow: 0 4px 6px rgba(0,0,0,0.1);">
                                    <iframe style="position: absolute; top: 0; left: 0; width: 100%; height: 100%;" 
                                            src="<?php echo $course['video_url']; ?>" 
                                            frameborder="0" allowfullscreen>
                                    </iframe>
                                </div>
                                <h4 style="margin: 10px 0 0 0; color: #333; text-align: left;"><?php echo $course['title']; ?></h4>
                            <?php else: ?>
                                <p style="color: red;">No course available for this sector yet.</p>
                            <?php endif; ?>
                        </div>

                        <a href="exams.php?sector=<?php echo $sector_id;?>&reset=true" class="btn-real" style="background: #2563eb; display: inline-block; width: auto; padding: 12px 30px; margin-top: 10px;">
                            Request Retake
                        </a>
                    </div>
                <?php endif; ?>

            <?php elseif ($mode == 'real'): ?>
                <div class="exam-card-pro">
                    <h3>Answer the following questions:</h3>
                    <form method="post">
                        <?php
                        $questions = $conn->query("SELECT * FROM questions WHERE exam_id=$exam_id ORDER BY RAND() LIMIT 5");
                        $i = 1;
                        if($questions->num_rows < 1) echo "<p>No questions found in database.</p>";
                        while($q = $questions->fetch_assoc()):
                        ?>
                        <div class="question-item">
                            <p><strong>Q<?php echo $i; ?>. <?php echo $q['question_text']; ?></strong></p>
                            <input type="hidden" name="id_q<?php echo $i; ?>" value="<?php echo $q['id']; ?>">
                            
                            <label style="display:block; padding:5px;"><input type="radio" name="q<?php echo $i; ?>" value="A"> <?php echo $q['opt_a']; ?></label>
                            <label style="display:block; padding:5px;"><input type="radio" name="q<?php echo $i; ?>" value="B"> <?php echo $q['opt_b']; ?></label>
                            <label style="display:block; padding:5px;"><input type="radio" name="q<?php echo $i; ?>" value="C"> <?php echo $q['opt_c']; ?></label>
                            <label style="display:block; padding:5px;"><input type="radio" name="q<?php echo $i; ?>" value="D"> <?php echo $q['opt_d']; ?></label>
                            <label style="display:block; padding:5px; color:#666;"><input type="radio" name="q<?php echo $i; ?>" value="SKIP" checked> Skip</label>
                        </div>
                        <?php $i++; endwhile; ?>
                        <button type="submit" class="btn-real">Submit Answers</button>
                    </form>
                </div>

            <?php else: ?>
                <div class="exam-card-pro">
                    <div class="exam-header">
                        <div class="exam-icon">📝</div>
                        <h3 style="margin:0;"><?php echo $exam['title']; ?></h3>
                    </div>
                    <div class="exam-stats">
                        <div class="stat-box"><span class="stat-val">5</span><span class="stat-label">Questions</span></div>
                        <div class="stat-box"><span class="stat-val">10 m</span><span class="stat-label">Duration</span></div>
                        <div class="stat-box"><span class="stat-val">70%</span><span class="stat-label">Pass Mark</span></div>
                    </div>
                    
                    <div class="demo-section">
                        <p class="demo-title">Demo Exam</p>
                        <button class="btn-demo" onclick="alert('This is just a demo button!')">Try Demo</button>
                    </div>

                    <div style="margin-top:20px;">
                        <p class="demo-title">Ready?</p>
                        <a href="exams.php?sector=<?php echo $sector_id; ?>&mode=real" class="btn-real">Start Real Exam</a>
                    </div>
                </div>
            <?php endif; ?>

        </div>
    </div>
</body>
</html>