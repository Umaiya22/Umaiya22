<?php
session_start();
include 'db_connect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];
    $result = $conn->query("SELECT * FROM users WHERE email='$email' AND password='$password'");

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $_SESSION['user_id'] = $row['id'];
        $_SESSION['name'] = $row['full_name'];
        $_SESSION['cgpa'] = $row['cgpa'];
        header("Location: dashboard.php");
    } else {
        $error = "Invalid email or password";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - CareerPrep</title>
    <link rel="stylesheet" href="style.css?v=2">
    <style>
        /* স্পেসিফিক লগিন পেজ স্টাইল যাতে ব্যাকগ্রাউন্ড ইমেজ পায় */
        body { margin: 0; font-family: 'Poppins', sans-serif; }
        .hero-bg {
            background: linear-gradient(rgba(0, 0, 0, 0.6), rgba(0, 0, 0, 0.7)), 
                        url('https://images.unsplash.com/photo-1497215728101-856f4ea42174?ixlib=rb-1.2.1&auto=format&fit=crop&w=1950&q=80');
            background-size: cover;
            background-position: center;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
        }
        .login-card {
            background: rgba(255, 255, 255, 0.95); /* একটু স্বচ্ছ সাদা */
            padding: 40px;
            width: 350px;
            border-radius: 15px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
            text-align: center;
        }
        input {
            width: 100%; padding: 12px; margin: 10px 0;
            border: 1px solid #ddd; border-radius: 6px; box-sizing: border-box;
        }
        button {
            width: 100%; padding: 12px; background: #2563eb; color: white;
            border: none; border-radius: 6px; font-weight: bold; cursor: pointer;
            margin-top: 10px;
        }
        button:hover { background: #1d4ed8; }
        a { text-decoration: none; color: #2563eb; font-weight: 600; }
    </style>
</head>
<body>
    <div class="hero-bg">
        <div class="login-card">
            <h2 style="margin-top:0; color:#1f2937;">Welcome Back</h2>
            <p style="color:#666; margin-bottom:20px;">Please login to your account</p>
            
            <form method="post">
                <input type="email" name="email" placeholder="Email Address" required>
                <input type="password" name="password" placeholder="Password" required>
                <button type="submit">Login</button>
            </form>
            
            <?php if(isset($error)) echo "<p style='color:red; margin-top:10px;'>$error</p>"; ?>
            
            <p style="margin-top:20px; font-size:14px;">
                Don't have an account? <a href="register.php">Register</a>
            </p>
            <p style="font-size:14px;">
                <a href="index.php">← Back to Home</a>
            </p>
        </div>
    </div>
</body>
</html>