<?php
session_start();
include 'db_connect.php';
if (!isset($_SESSION['user_id'])) header("Location: index.php");

$uid = $_SESSION['user_id'];
$passed_count = $conn->query("SELECT count(*) as c FROM user_exam_results WHERE user_id=$uid AND status='PASS'")->fetch_assoc()['c'];
$total_sectors = $conn->query("SELECT count(*) as c FROM sectors")->fetch_assoc()['c'];
?>
<!DOCTYPE html>
<html>
<head><link rel="stylesheet" href="style.css?v=8"></head>
<body>
    <div class="app-container">
        <?php include 'sidebar.php'; ?>

        <div class="main-content">
            <div class="header-welcome">
                <div>
                    <h1 style="margin:0;">Dashboard</h1>
                    <p style="color:#6b7280; margin:5px 0 0 0;">Track your career progress</p>
                </div>
                <div class="user-badge">👤 <?php echo $_SESSION['name']; ?></div>
            </div>

            <div class="stats-grid">
                <div class="stat-card" style="border-bottom-color: #2563eb;">
                    <h3>Your CGPA</h3>
                    <div class="value"><?php echo $_SESSION['cgpa']; ?></div>
                </div>
                <div class="stat-card" style="border-bottom-color: #10b981;">
                    <h3>Skills Certified</h3>
                    <div class="value"><?php echo $passed_count; ?> / <?php echo $total_sectors; ?></div>
                </div>
                <div class="stat-card" style="border-bottom-color: #f59e0b;">
                    <h3>Job Markets</h3>
                    <div class="value"><?php echo $total_sectors; ?> Sectors</div>
                </div>
            </div>

            <h2 style="margin-bottom:20px;">Start Your Journey</h2>
            <div class="action-grid">
                <div class="card-action">
                    <div>
                        <h3 style="color:#111827;">💼 Explore Jobs</h3>
                        <p style="color:#666;">Browse jobs by sector. If you are eligible, apply instantly. If locked, take the specific exam.</p>
                    </div>
                    <a href="jobs.php" class="btn-action" style="background:#2563eb;">Find a Job →</a>
                </div>

                <div class="card-action">
                    <div>
                        <h3 style="color:#111827;">🎬 Prepare with Courses</h3>
                        <p style="color:#666;">Watch video tutorials to prepare for sector-specific exams.</p>
                    </div>
                    <a href="courses.php" class="btn-action" style="background:#4b5563;">Browse Courses →</a>
                </div>
            </div>
        </div>
    </div>
</body>
</html>