<?php
session_start();
include 'db_connect.php';
if (!isset($_SESSION['user_id'])) header("Location: index.php");

$uid = $_SESSION['user_id'];

// ১. ইউজারের বর্তমান তথ্য আনা (যাতে আগের CGPA ইনপুট বক্সে দেখায়)
$user_query = $conn->query("SELECT * FROM users WHERE id=$uid");
$user_data = $user_query->fetch_assoc();
$user_email = $user_data['email'];
$user_name = $user_data['full_name'];
$current_cgpa = $user_data['cgpa'];

// ২. সেভ লজিক (CGPA সহ)
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $summary = $conn->real_escape_string($_POST['summary']);
    $skills = $conn->real_escape_string($_POST['skills']);
    $cgpa = $_POST['cgpa']; // নতুন CGPA ইনপুট
    
    // A. Resume টেবিল আপডেট
    $check = $conn->query("SELECT id FROM resumes WHERE user_id=$uid");
    if($check->num_rows > 0) {
        $conn->query("UPDATE resumes SET summary='$summary', skills='$skills' WHERE user_id=$uid");
    } else {
        $conn->query("INSERT INTO resumes (user_id, summary, skills) VALUES ($uid, '$summary', '$skills')");
    }

    // B. Users টেবিলে CGPA আপডেট (যাতে প্রোফাইলে শো করে)
    $conn->query("UPDATE users SET cgpa='$cgpa' WHERE id=$uid");
    $_SESSION['cgpa'] = $cgpa; // সেশনেও আপডেট করা হলো

    // রিফ্রেশ করা যাতে নতুন ডাটা দেখায়
    header("Location: resume.php");
    exit();
}

// ৩. রিজিউম ডাটা আনা
$resume = $conn->query("SELECT * FROM resumes WHERE user_id=$uid")->fetch_assoc();
?>

<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="style.css?v=6">
    <script>
        function update() {
            document.getElementById('p_summary').innerText = document.getElementById('in_summary').value;
            let skills = document.getElementById('in_skills').value;
            if(skills) document.getElementById('p_skills').innerText = skills;
            
            // লাইভ প্রিভিউতে CGPA দেখানো
            document.getElementById('p_cgpa').innerText = "CGPA: " + document.getElementById('in_cgpa').value;
        }
    </script>
    <style>
        .split-layout { display: flex; gap: 30px; align-items: flex-start; }
        .form-box { flex: 1; background: white; padding: 30px; border-radius: 12px; box-shadow: 0 2px 10px rgba(0,0,0,0.05); }
        .preview-box { flex: 1; background: white; padding: 40px; border-radius: 8px; border-top: 5px solid #2563eb; box-shadow: 0 10px 25px rgba(0,0,0,0.1); min-height: 400px; }
        label { font-weight: 600; margin-bottom: 8px; display: block; color: #333; }
        textarea, input[type="text"], input[type="number"] { width: 100%; padding: 12px; margin-bottom: 20px; border: 1px solid #ddd; border-radius: 6px; box-sizing: border-box; font-family: inherit; }
        .section-title { border-bottom: 2px solid #e5e7eb; padding-bottom: 5px; margin-top: 25px; margin-bottom: 10px; font-weight: 700; color: #2563eb; text-transform: uppercase; font-size: 14px; }
    </style>
</head>
<body>
    <div class="app-container">
        <?php include 'sidebar.php'; ?>
        
        <div class="main-content">
            <h1 style="margin-bottom: 30px;">Resume Builder</h1>
            
            <div class="split-layout">
                <div class="form-box">
                    <h3 style="margin-top:0; border-bottom:1px solid #eee; padding-bottom:15px;">Update Details</h3>
                    <form method="post">
                        
                        <div style="background: #fff7ed; padding: 15px; border: 1px solid #fdba74; border-radius: 8px; margin-bottom: 20px;">
                            <label style="color: #c2410c;">Education: CGPA</label>
                            <input type="number" step="0.01" name="cgpa" id="in_cgpa" onkeyup="update()" value="<?php echo $current_cgpa; ?>" placeholder="e.g. 3.50" required style="margin-bottom:0;">
                            <small style="color:#ea580c;">This will automatically update your Profile.</small>
                        </div>

                        <label>Professional Summary</label>
                        <textarea name="summary" id="in_summary" onkeyup="update()" rows="6" placeholder="Write a short summary..."><?php echo $resume['summary'] ?? ''; ?></textarea>
                        
                        <label>Skills (Comma separated)</label>
                        <input type="text" name="skills" id="in_skills" onkeyup="update()" value="<?php echo $resume['skills'] ?? ''; ?>" placeholder="e.g. PHP, React, MySQL">
                        
                        <button type="submit" class="btn-primary">Save Resume & CGPA</button>
                    </form>
                </div>

                <div class="preview-box">
                    <div style="text-align:right; margin-bottom:10px;">
                        <span style="background:#eff6ff; color:#2563eb; padding:5px 10px; border-radius:15px; font-size:12px; font-weight:bold;">Live Preview</span>
                    </div>

                    <div class="preview-header">
                        <h1 style="margin:0; text-transform:capitalize;"><?php echo $user_name; ?></h1>
                        <p style="margin:0; color:#666;"><?php echo $user_email; ?></p>
                        <p id="p_cgpa" style="margin-top:5px; font-weight:bold; color:#2563eb;">CGPA: <?php echo $current_cgpa; ?></p>
                    </div>
                    
                    <div class="preview-content">
                        <div class="section-title">Professional Summary</div>
                        <p id="p_summary" style="color:#4b5563; line-height:1.6;">
                            <?php echo $resume['summary'] ?? 'Start typing...'; ?>
                        </p>
                        
                        <div class="section-title">Skills</div>
                        <p id="p_skills" style="color:#111; font-weight:500;">
                            <?php echo $resume['skills'] ?? 'No skills added'; ?>
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>