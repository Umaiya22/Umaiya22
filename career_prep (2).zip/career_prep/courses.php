<?php
session_start();
include 'db_connect.php';
if (!isset($_SESSION['user_id'])) header("Location: index.php");
?>
<!DOCTYPE html>
<html>
<head><link rel="stylesheet" href="style.css?v=9"></head>
<body>
    <div class="app-container">
        <?php include 'sidebar.php'; ?>
        <div class="main-content">
            <h1 style="margin-bottom:10px;">Explore Courses</h1>
            
            <div class="search-section">
                <input type="text" class="search-input" placeholder="Search courses...">
                <div class="filters">
                    <select class="filter-select"><option>All Categories</option></select>
                    <select class="filter-select"><option>Level: Any</option></select>
                    <select class="filter-select"><option>Duration: Any</option></select>
                </div>
            </div>
            
            <p style="color:#666; margin-bottom:20px;">Showing available courses</p>

            <div class="card-grid">
                <?php
                // ডাটাবেস থেকে সব কোর্স আনা
                $courses = $conn->query("SELECT c.*, s.name as sector_name FROM courses c JOIN sectors s ON c.sector_id = s.id");
                
                while($row = $courses->fetch_assoc()):
                ?>
                <div class="course-card">
                    <div class="course-thumb" style="background-image: url('https://placehold.co/600x400/0056D2/ffffff?text=<?php echo urlencode($row['title']); ?>');"></div>
                    
                    <div class="course-content">
                        <div class="course-tags">
                            <span class="tag-badge"><?php echo $row['sector_name']; ?></span>
                            <span class="tag-badge" style="background:#f3f4f6; color:#4b5563;"><?php echo $row['level']; ?></span>
                        </div>
                        
                        <h3 class="course-title"><?php echo $row['title']; ?></h3>
                        <p class="course-desc"><?php echo substr($row['description'], 0, 80); ?>...</p>
                        
                        <div class="course-meta">
                            <span>🕒 <?php echo $row['duration']; ?></span>
                            <span style="color:#eab308;">★ <?php echo $row['rating']; ?></span>
                        </div>
                        
                        <button class="btn-view-course" onclick="window.open('<?php echo $row['video_url']; ?>', '_blank')">View Course</button>
                    </div>
                </div>
                <?php endwhile; ?>
            </div>
        </div>
    </div>
</body>
</html>